package com.example.TestMediaSoft.entities.personEntities;

public abstract class Person {

}
